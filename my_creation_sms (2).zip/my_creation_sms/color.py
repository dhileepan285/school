color_1 = "gray95"
color_2 = "pink"
color_3 = "black"
color_4 = "white"

font_1 = "times new roman"
font_2 = "helvetica"