# User database
host = 'localhost'
user = 'root'
password = 'madysakthi41'
database = 'student_management'